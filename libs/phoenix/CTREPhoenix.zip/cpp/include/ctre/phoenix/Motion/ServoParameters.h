#pragma once

namespace CTRE { namespace Motion {

class ServoParameters{
public:
	float P = 0;
	float I = 0;
	float D = 0;
};

}}